import fs from 'node:fs';
import path from 'node:path';
// Flat, self-contained GitHub Pages package, suitable for GitHub's web uploader.
// Framework imports and static asset references are rewritten together.
const source='dist/client', target='outputs/github-pages';
fs.mkdirSync(target,{recursive:true});
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
const files=walk(source).filter(p=>!p.endsWith('/_headers')&&!p.endsWith('/Bingshen-Lau-CV-zh.html'));
const names=new Set();
const mapping=files.map(p=>{const name=path.basename(p);if(names.has(name))throw Error('Duplicate filename: '+name);names.add(name);return ['/'+path.relative(source,p).replaceAll(path.sep,'/'),'/'+name];});
for(const file of files){let data=fs.readFileSync(file);if(/\.(html|js|css|json|rsc)$/.test(file)){let text=data.toString();for(const [from,to]of mapping)text=text.replaceAll(from,to);data=Buffer.from(text);}fs.writeFileSync(path.join(target,path.basename(file)),data);}
fs.writeFileSync(path.join(target,'.nojekyll'),'');
console.log(`${files.length} static files exported to ${target}`);
