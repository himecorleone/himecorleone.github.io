import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'Bingshen (Benjamin) Lau | Environmental & Geospatial Data',
  description: 'Bingshen (Benjamin) Lau, environmental engineering MSc student at Technische Universität Darmstadt. Research interests, education and experience.',
  icons: { icon: '/favicon.svg' },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" suppressHydrationWarning><body>{children}</body></html>;
}
