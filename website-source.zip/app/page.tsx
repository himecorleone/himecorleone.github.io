'use client';

import { useEffect, useState } from 'react';
import { ArrowDown, ArrowUpRight, Moon, Sun, MapPin, Mail } from 'lucide-react';
import { Sidebar, SidebarProvider } from '@/components/ui/sidebar';
import translations from './translations.json';
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext, type CarouselApi } from '@/components/ui/carousel';
import { Switch } from '@/components/ui/switch';

const sections = [['about', 'About'], ['research', 'Research interests'], ['education', 'Education'], ['experience', 'Experience'], ['recognition', 'Scholarships'], ['more', 'A little more']] as const;

export default function Home() {
  // Chinese translations are retained; enable here when ready to show the switch again.
  const language: 'en' | 'zh' = 'en' as 'en' | 'zh';
  const t = (text: string) => language === 'zh' ? (translations as Record<string, string>)[text] ?? text : text;
  const [climbingApi, setClimbingApi] = useState<CarouselApi>();
  const [climbingSlide, setClimbingSlide] = useState(0);
  useEffect(() => {
    if (!climbingApi) return;
    const updateSlide = () => setClimbingSlide(climbingApi.selectedScrollSnap());
    updateSlide();
    climbingApi.on('select', updateSlide);
    climbingApi.on('reInit', updateSlide);
    return () => { climbingApi.off('select', updateSlide); climbingApi.off('reInit', updateSlide); };
  }, [climbingApi]);
  const [dark, setDark] = useState(false);
  const [active, setActive] = useState('about');
  useEffect(() => {
    try { const value = localStorage.getItem('benjamin-theme') === 'dark'; setDark(value); document.documentElement.classList.toggle('dark', value); } catch {}
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) if (entry.isIntersecting) setActive(entry.target.id);
    }, { rootMargin: '-12% 0px -60% 0px', threshold: 0 });
    document.querySelectorAll('main section[id]').forEach(section => observer.observe(section));
    return () => observer.disconnect();
  }, []);
  function changeTheme(value: boolean) {
    setDark(value); document.documentElement.classList.toggle('dark', value);
    try { localStorage.setItem('benjamin-theme', value ? 'dark' : 'light'); } catch {}
  }
  return <SidebarProvider className="site-shell">
    <a className="skip-link" href="#about">{t("Skip to content")}</a>
    <Sidebar collapsible="none" className="profile-sidebar">
      <div className="profile-identity">
        <img className="profile-photo" src="/images/benjamin-outdoors.jpg" alt={t("Benjamin outdoors in the mountains")} width="108" height="108"/>
        <h1>Bingshen<br/><span>(Benjamin) Lau</span></h1>
        <p className="affiliation">{t("MSc student")}<br/>{t("Technische Universität Darmstadt")}</p>
        <p className="location"><MapPin size={14}/>{' '}{t("Germany")}</p>
        <a className="profile-email" href="mailto:bingshen.liu@stud.tu-darmstadt.de"><Mail size={14} aria-hidden="true"/><span>bingshen.liu@<wbr/>stud.tu-darmstadt.de</span></a>
      </div>
      <nav aria-label={t("Main navigation")}>{sections.map(([id, label], index) => <a key={id} href={`#${id}`} aria-current={active === id ? 'location' : undefined} className={active === id ? 'current' : ''} onClick={() => setActive(id)}><span className="nav-number">0{index + 1}</span>{t(label)}<span className="nav-dot"/></a>)}</nav>
      <div className="sidebar-bottom"><a href="mailto:bingshen.liu@stud.tu-darmstadt.de"><Mail size={16}/>{' '}{t("Get in touch")}{' '}<ArrowUpRight size={15}/></a><div className="theme-control"><label htmlFor="theme">{dark ? <Moon size={15}/> : <Sun size={15}/>}{' '}{t("Dark mode")}</label><Switch id="theme" checked={dark} onCheckedChange={changeTheme}/></div></div>
    </Sidebar>
    <main>
      <div className="topline"><span>{t("ENVIRONMENT · DATA · TECHNOLOGY")}</span><a href="mailto:bingshen.liu@stud.tu-darmstadt.de">{t("Say hello")}{' '}<ArrowUpRight size={14}/></a></div>
      <section id="about" className="about-section">
        <p className="eyebrow section-kicker">{t("01 / ABOUT")}</p>
        <h2>{t("Hello, I’m Bingshen")}<span className="accent">.</span></h2>
        <p className="lead">{t("Exploring environmental questions")}<br className="desktop-break"/>{' '}{t("through geospatial data.")}</p>
        <div className="intro-copy"><p>{t("I’m an environmental engineering graduate and an MSc student in Tropical Hydrogeology and Environmental Engineering at")}{' '}<a href="https://www.tu-darmstadt.de/" target="_blank" rel="noreferrer">{t("Technische Universität Darmstadt")}{' '}<ArrowUpRight size={13}/></a>{t(", Germany.")}</p><p>{t("My background brings together GIS and remote sensing, computational methods, and hands-on environmental data collection. I’m interested in how these tools can help us understand the environments we live in.")}</p><p>{t("Previously, I studied environmental engineering at Óbuda University in Hungary and gained internship experience in laboratory analysis and data management.")}</p></div>
        <div className="facts"><div><span>{t("Current stage")}</span><strong>{t("Master’s thesis remaining")}</strong></div><div><span>{t("Focus")}</span><strong>{t("Geospatial & environmental data")}</strong></div></div>
        <div className="about-links"><a className="cv-link" href={language === 'zh' ? '/Bingshen-Lau-CV-zh.html' : '/Benjamin-Lau-CV.html'} target="_blank" rel="noreferrer">{t("View CV")}{' '}<ArrowUpRight size={16}/></a><a className="email-link" href="mailto:bingshen.liu@stud.tu-darmstadt.de">bingshen.liu@stud.tu-darmstadt.de <ArrowUpRight size={15}/></a></div>
        <a className="scroll-cue" href="#research">{t("Research interests")}{' '}<ArrowDown size={15}/></a>
      </section>
      <section id="research"><p className="eyebrow section-kicker">{t("02 / RESEARCH INTERESTS")}</p><h2>{t("Understanding our environment.")}</h2><p className="section-intro">{t("I’m interested in connecting environmental observations with computational methods, particularly in the following areas.")}</p><div className="research-list">{[
        ['01', 'Remote sensing & 3D mapping', 'LiDAR, satellite observations and three-dimensional mapping of urban environments.', 'OBSERVE'],
        ['02', 'Geospatial data fusion', 'Combining sensor and geospatial data for environmental monitoring and flood-resilience assessment.', 'CONNECT'],
        ['03', 'Machine learning for environmental data', 'Exploring machine learning and computer vision methods for environmental observations.', 'UNDERSTAND']
      ].map(([n, title, text, tag]) => <article key={n}><span className="research-index">{n}</span><div><h3>{t(title)}</h3><p>{t(text)}</p></div><span className="research-tag">{t(tag)}</span></article>)}</div><div className="thesis-note"><span>{t("THESIS DIRECTION")}</span><p>{t("I would like to develop a master’s thesis connecting LiDAR or satellite observations with data fusion and machine-learning methods for water-related applications.")}</p></div></section>
      <section id="education"><p className="eyebrow section-kicker">{t("03 / EDUCATION")}</p><h2>{t("An international academic path.")}</h2><div className="timeline"><article><p className="date">{t("2019 — PRESENT")}</p><div><span className="status">{t("IN PROGRESS")}</span><h3>{t("MSc, Tropical Hydrogeology and Environmental Engineering")}</h3><p className="institution">{t("Technische Universität Darmstadt · Germany")}</p><p>{t("All requirements other than the master’s thesis completed. Coursework includes Computer Vision, Building Modeling, remote sensing and statistics, GIS, integrated water-resource management, and water treatment and analysis.")}</p></div></article><article><p className="date">2016 — 2019</p><div><h3>{t("BSc, Environmental Engineering")}</h3><p className="institution">{t("Óbuda University · Hungary")}</p><p>{t("Focus on water treatment, with coursework in QGIS, environmental simulation and water-quality protection.")}</p><p className="thesis-title">{t("Bachelor’s thesis:")}{' '}<em>{t("Cleaned Wastewater Irrigation in Agriculture")}</em></p></div></article><article><p className="date">2015 — 2016</p><div><h3>{t("Electrical engineering studies")}</h3><p className="institution">{t("Óbuda University · Hungary")}</p><p>{t("Coursework in control systems, digital techniques, electricity and electronics.")}</p></div></article></div></section>
      <section id="experience"><p className="eyebrow section-kicker">{t("04 / EXPERIENCE")}</p><h2>{t("From samples to datasets.")}</h2><div className="timeline"><article><p className="date">{t("OCT — DEC 2020")}</p><div><h3>{t("Data Management Assistant")}</h3><p className="institution">{t("Dah Sing Bank · China · Internship")}</p><p>{t("Supported data collection and mobile software verification, and assisted with database deployment and maintenance.")}</p></div></article><article><p className="date">{t("APR — DEC 2018")}</p><div><h3>{t("Assistant Laboratory Technician")}</h3><p className="institution">{t("National Agricultural Research and Innovation Centre · Hungary · Internship")}</p><p>{t("Collected and analysed data, prepared samples, and supported model investigation and verification. Worked with gas chromatography, HPLC-UV and spectrophotometric analysis.")}</p></div></article></div><div className="training"><h3>{t("Additional training")}</h3><article className="course-entry"><h4>{t("Computational Methods for Building Physics and Construction Materials")}</h4><p>{t("RILEM EAC course · Darmstadt, Germany · 12–16 April 2021")}</p><a href="/certificates/rilem-2021.jpg" target="_blank" rel="noreferrer">{t("View certificate of participation")}{' '}<ArrowUpRight size={14}/></a></article><article className="course-entry"><h4>NVIDIA · {t("Rapid Application Development with Large Language Models (LLMs)")}</h4></article><article className="course-entry"><h4>NVIDIA · {t("Fundamentals of Deep Learning")}</h4></article></div><h3 className="tool-heading">{t("Tools & technical background")}</h3><div className="skills-grid"><div><h4>{t("Analysis")}</h4><p>Python · MATLAB · PAST4</p></div><div><h4>{t("Geospatial")}</h4><p>QGIS · ArcGIS · ArcGIS Pro · SNAP</p></div><div><h4>{t("Environmental modelling")}</h4><p>{t("LiDAR data processing · MODFLOW")}</p></div><div><h4>{t("Scientific communication")}</h4><p>{t("LaTeX · Technical writing · Presentations")}</p></div></div></section>
      <section id="recognition"><p className="eyebrow section-kicker">{t("05 / SCHOLARSHIPS")}</p><h2>{t("Support along the way.")}</h2><div className="awards"><article><span>2019 — 2020</span><h3>{t("Deutschlandstipendium")}</h3></article><article><span>2015 — 2019</span><div><h3>{t("Stipendium Hungaricum")}</h3><p>{t("Tempus Public Foundation · Full scholarship")}</p></div></article><article><span>2015 — 2019</span><div><h3>{t("China Scholarship Council")}</h3><p>{t("Full scholarship")}</p></div></article></div></section>
      <section id="more"><p className="eyebrow section-kicker">{t("06 / A LITTLE MORE")}</p><h2>{t("Outside my studies.")}</h2><p>{t("Outside my studies, I enjoy outdoor rock climbing, badminton, tennis, swimming, table tennis and hiking.")}</p><div className="climbing-gallery"><h3>{t("Rock climbing · 2025")}</h3><Carousel className="climbing-carousel" opts={{ loop: true }} setApi={setClimbingApi} aria-label="Climbing photo album" tabIndex={0}><CarouselContent>{[
        ['/images/climbing-2025-solo.jpg', 'On the rock face', 'Bingshen climbing beside a rock face with mountains in the background'],
        ['/images/climbing-2025-team-snow.jpg', 'With the team', 'Group selfie during a snowy mountain outing'],
        ['/images/climbing-2025-team-summit.jpg', 'Up in the mountains', 'The group posing together in the mountains'],
        ['/images/climbing-2025-team-mountains.jpg', 'A day outdoors together', 'Group photo against a snowy mountain landscape'],
        ['/images/climbing-2025-team-trail.jpg', 'Along the trail', 'The group walking beneath a rocky overhang']
      ].map(([file, caption, alt], index) => <CarouselItem key={file} aria-label={`${index + 1} of 5`} aria-hidden={index !== climbingSlide}><figure><button className="climbing-photo-button" type="button" onClick={() => climbingApi?.scrollNext()} aria-label="Show next climbing photo" tabIndex={index === climbingSlide ? 0 : -1}><img src={file} alt={t(alt)} loading="lazy" width="1600" height="1200"/></button><figcaption>{t(caption)}</figcaption></figure></CarouselItem>)}</CarouselContent><div className="climbing-controls"><span aria-live="polite" aria-atomic="true">{climbingSlide + 1} / 5</span><div className="climbing-arrows"><CarouselPrevious aria-label="Previous climbing photo"/><CarouselNext aria-label="Next climbing photo"/></div></div></Carousel></div><figure className="personal-photo"><img src="/images/benjamin-and-cat.jpg" alt={t("Benjamin holding a cat")} width="825" height="1100" loading="lazy"/><figcaption>{t("A moment away from the desk.")}</figcaption></figure><h3 className="international-heading">{t("Across languages and places.")}</h3><p>{t("Living and studying overseas for approximately eleven years has given me experience across different academic and cultural settings, including academic writing and presentations in English.")}</p><div className="languages">{[['English','Proficient'],['Chinese','Native'],['Hungarian','Intermediate'],['German','Beginner']].map(([language, level]) => <div key={language}><strong>{t(language)}</strong><span>{t(level)}</span></div>)}</div><div className="contact-line"><p>{t("For research and professional enquiries")}</p><a href="mailto:bingshen.liu@stud.tu-darmstadt.de">{t("Let’s get in touch")}{' '}<ArrowUpRight size={20}/></a></div></section>
      <footer className="page-footer"><span>© {new Date().getFullYear()} Bingshen (Benjamin) Lau</span><a href="#about">{t("Back to top ↑")}</a></footer>
    </main>
  </SidebarProvider>;
}
